package Checkers;


import org.junit.jupiter.api.Test;

public class SampleTest {

    @Test
    public void simpleTest() {
        
    }
}
